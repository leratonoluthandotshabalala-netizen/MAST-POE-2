// import React from 'react';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import MenuListScreen from '../screens/MenuListScreen';
// import ItemDetailsScreen from '../screens/ItemDetailsScreen';

// export type MenuStackParamList = {
//   MenuList: undefined;
//   ItemDetails: { item: any };
// };

// const Stack = createNativeStackNavigator<MenuStackParamList>();

// export default function MenuStack() {
//   return (qa
//     <Stack.Navigator screenOptions={{ headerShown: false }}>
//       <Stack.Screen name="MenuList" component={MenuListScreen} />
//       <Stack.Screen name="ItemDetails" component={ItemDetailsScreen} />
//     </Stack.Navigator>
//   );
// }

